<?php

namespace Kanboard\Plugin\ContentCleaner;

use Kanboard\Core\Plugin\Base;
use Kanboard\Core\Security\Role;
use Kanboard\Core\Translator;

/**
 * Register ContentCleaner services, routes and administrator-only access.
 *
 * Related tests: tests/security_contract.php, tests/kanboard_integration.php
 * and tests/cleanup_plan_integration.php.
 */
class Plugin extends Base
{
    public function initialize()
    {
        // Database inspection and cleaning must never be reachable by non-administrators.
        $this->applicationAccessMap->add('ContentCleanerController', '*', Role::APP_ADMIN);
        $this->applicationAccessMap->add('CleaningController', '*', Role::APP_ADMIN);
        $this->applicationAccessMap->add('PluginCleaningController', '*', Role::APP_ADMIN);

        // Views - Add Menu Item - Template Hook
        //  - Override name should start lowercase e.g. pluginNameExampleCamelCase
        $this->template->hook->attach('template:config:sidebar', 'contentCleaner:config/sidebar');

        // Extra Page - Routes
        //  - Example: $this->route->addRoute('/my/custom/route', 'MyController', 'show', 'PluginNameExampleStudlyCaps');
        //  - Must have the corresponding action in the matching controller
        $this->route->addRoute('/settings/cleaner', 'ContentCleanerController', 'show', 'ContentCleaner');

        // Helper
        //  - Example: $this->helper->register('helperClassNameCamelCase', '\Kanboard\Plugin\PluginNameExampleStudlyCaps\Helper\HelperNameExampleStudlyCaps');
        //  - Add each Helper in the 'use' section at the top of this file
        $this->helper->register('cleaningHelper', '\Kanboard\Plugin\ContentCleaner\Helper\CleaningHelper');
        $this->helper->register('defaultTableHelper', '\Kanboard\Plugin\ContentCleaner\Helper\DefaultTableHelper');
        $this->helper->register('pluginCleaningHelper', '\Kanboard\Plugin\ContentCleaner\Helper\PluginCleaningHelper');
    }

    public function onStartup()
    {
        Translator::load($this->languageModel->getCurrentLanguage(), __DIR__ . '/Locale');

        // The startup event runs after the session opens and the route is dispatched.
        $isCleanerPage = $this->router->getPlugin() === 'ContentCleaner'
            && in_array(
                $this->router->getController(),
                array('ContentCleanerController', 'CleaningController', 'PluginCleaningController'),
                true
            );

        if ($this->userSession->isAdmin() && $isCleanerPage) {
            $this->hook->on('template:layout:css', array('template' => 'plugins/ContentCleaner/Assets/css/content-cleaner.css'));
            $this->hook->on('template:layout:css', array('template' => 'plugins/ContentCleaner/Assets/css/content-cleaner-icons.css'));
            $this->hook->on('template:layout:css', array('template' => 'plugins/ContentCleaner/Assets/css/messages.css'));
        }
    }

    public function getClasses()
    {
        return [
            'Plugin\ContentCleaner\Model' => [
                'ApplicationCleaningModel', 'CleanupPlanModel', 'PluginCleaningModel'
            ],
        ];
    }

    public function getPluginName()
    {
        // Plugin Name MUST be identical to namespace for Plugin Directory to detect updated versions - do not translate the plugin name here
        return 'ContentCleaner';
    }

    public function getPluginDescription()
    {
        return t('This tool allows admins to cleanup their Kanboard database by selectively deleting useless data saved by Kanboard and leftover data after uninstalling plugins. Keep your database clean and free from cluttered and expired data using cleaning jobs to solve specific application issues.');
    }

    public function getPluginAuthor()
    {
        return 'aljawaid';
    }

    public function getPluginVersion()
    {
        return '2.0.5';
    }

    public function getCompatibleVersion()
    {
        // Examples: '>=1.0.37' '<1.0.37' '<=1.0.37'
        // Version 2.0.5 is tested against the current Kanboard 1.2.54 interfaces.
        return '>=1.2.54';
    }

    public function getPluginHomepage()
    {
        return 'https://github.com/aljawaid/ContentCleaner';
    }
}
