# Changelog


## v1.0

### What's Changed

_(most recent changes are listed on top):_
- Initial release
- Delete Plugin Cleaning Jobs feature disabled
- Translations starter template included
- Major Contributors: @alfredbuehler @creecros

---

Read the full [**Changelog**](../master/changelog.md "See changes") or view the [**README**](../master/README.md "View README")
