<?= t('Core tables are created by only the application. Plugins can only alter these types of tables but not delete them.') ?>
