<?= t('These columns are located inside core tables and will be deleted if created by a plugin') ?>
