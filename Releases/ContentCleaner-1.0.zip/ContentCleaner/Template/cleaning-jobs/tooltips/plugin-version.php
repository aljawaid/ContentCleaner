<?= t('This cleaning job is compatible with all versions of this plugin up to v%s', $plugin['checked_up_to_plugin_version']) ?>
